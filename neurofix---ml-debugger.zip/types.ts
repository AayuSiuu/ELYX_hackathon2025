import { Type } from "@google/genai";

export enum DebugMode {
  STATIC_ANALYSIS = 'STATIC_ANALYSIS',
  TRAINING_SIMULATION = 'TRAINING_SIMULATION',
  CHAT = 'CHAT',
  ARCHITECTURE_DIAGRAM = 'ARCHITECTURE_DIAGRAM'
}

export interface AnalysisResult {
  summary: string;
  issues: Issue[];
  fixedCode?: string;
}

export interface Issue {
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  line?: number;
  description: string;
  suggestion: string;
}

export interface TrainingMetric {
  epoch: number;
  loss: number;
  val_loss: number;
  accuracy: number;
  val_accuracy: number;
}

export interface SimulationResult {
  description: string;
  metrics: TrainingMetric[];
  diagnosis: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  content: string;
  timestamp: number;
}

// Schema definitions for JSON output
export const ISSUE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    severity: { type: Type.STRING, enum: ['CRITICAL', 'WARNING', 'INFO'] },
    line: { type: Type.INTEGER },
    description: { type: Type.STRING },
    suggestion: { type: Type.STRING }
  },
  required: ['severity', 'description', 'suggestion']
};

export const ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    summary: { type: Type.STRING },
    issues: {
      type: Type.ARRAY,
      items: ISSUE_SCHEMA
    },
    fixedCode: { type: Type.STRING }
  },
  required: ['summary', 'issues']
};

export const METRIC_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    epoch: { type: Type.INTEGER },
    loss: { type: Type.NUMBER },
    val_loss: { type: Type.NUMBER },
    accuracy: { type: Type.NUMBER },
    val_accuracy: { type: Type.NUMBER }
  },
  required: ['epoch', 'loss', 'val_loss', 'accuracy', 'val_accuracy']
};

export const SIMULATION_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    description: { type: Type.STRING },
    diagnosis: { type: Type.STRING },
    metrics: {
      type: Type.ARRAY,
      items: METRIC_SCHEMA
    }
  },
  required: ['description', 'metrics', 'diagnosis']
};