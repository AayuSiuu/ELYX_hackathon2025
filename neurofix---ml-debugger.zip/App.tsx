import React, { useState, useRef } from 'react';
import { DebugMode, AnalysisResult, SimulationResult, ChatMessage } from './types';
import { analyzeCode, simulateTraining, sendChatMessage, analyzeDiagram } from './services/geminiService';
import { CodeEditor } from './components/CodeEditor';
import { AnalysisPanel } from './components/AnalysisPanel';
import { LandingPage } from './components/LandingPage';
import { BugIcon, ChartIcon, ChatIcon, PlayIcon, SparklesIcon, HomeIcon, EyeIcon, UploadIcon } from './components/Icons';
import ReactMarkdown from 'react-markdown';

const DEFAULT_CODE = `import torch
import torch.nn as nn
import torch.optim as optim

class SimpleNet(nn.Module):
    def __init__(self):
        super(SimpleNet, self).__init__()
        self.fc1 = nn.Linear(784, 128)
        # Potential Bug: Mismatch in dimensions if input isn't flattened
        self.fc2 = nn.Linear(64, 10) 

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x

model = SimpleNet()
optimizer = optim.SGD(model.parameters(), lr=0.01) # Learning rate might be too low
`;

export default function App() {
  const [hasStarted, setHasStarted] = useState(false);
  const [activeTab, setActiveTab] = useState<DebugMode>(DebugMode.STATIC_ANALYSIS);
  const [code, setCode] = useState<string>(DEFAULT_CODE);
  const [scenario, setScenario] = useState<string>("The model loss decreases initially but then spikes up and oscillates wildly after epoch 10.");
  
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [simulationResult, setSimulationResult] = useState<SimulationResult | null>(null);
  const [diagramResult, setDiagramResult] = useState<AnalysisResult | null>(null);
  
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([{role: 'model', content: "Hello! I'm NeuroFix. How can I help you debug your model today?", timestamp: Date.now()}]);
  const [chatInput, setChatInput] = useState("");
  
  // Image Upload State
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [imageMimeType, setImageMimeType] = useState<string>("image/png");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [useDeepThink, setUseDeepThink] = useState(false);

  const handleAnalyze = async () => {
    setIsLoading(true);
    try {
      const result = await analyzeCode(code, useDeepThink);
      setAnalysisResult(result);
    } catch (e) {
      alert("Analysis failed. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSimulate = async () => {
    setIsLoading(true);
    try {
      const result = await simulateTraining(scenario);
      setSimulationResult(result);
    } catch (e) {
      alert("Simulation failed.");
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleAnalyzeDiagram = async () => {
    if (!uploadedImage) return;
    setIsLoading(true);
    try {
      // Remove data URL header if present for processing (though some APIs might want it, our service splits it if needed)
      // Actually, standard Base64 for Gemini usually excludes the header.
      const base64Data = uploadedImage.split(',')[1];
      const result = await analyzeDiagram(base64Data, imageMimeType);
      setDiagramResult(result);
    } catch (e) {
        console.error(e);
        alert("Diagram analysis failed.");
    } finally {
        setIsLoading(false);
    }
  }

  const handleChatSend = async () => {
    if (!chatInput.trim()) return;
    const userMsg: ChatMessage = { role: 'user', content: chatInput, timestamp: Date.now() };
    setChatHistory(prev => [...prev, userMsg]);
    setChatInput("");
    setIsLoading(true);
    
    try {
      const responseText = await sendChatMessage(chatHistory.concat(userMsg), userMsg.content);
      const botMsg: ChatMessage = { role: 'model', content: responseText, timestamp: Date.now() };
      setChatHistory(prev => [...prev, botMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  // Drag and Drop Handlers
  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  const onDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };
  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };
  const onFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };
  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
        alert("Please upload an image file.");
        return;
    }
    setImageMimeType(file.type);
    const reader = new FileReader();
    reader.onload = (e) => {
        if (e.target?.result) {
            setUploadedImage(e.target.result as string);
            setDiagramResult(null); // Reset previous result
        }
    };
    reader.readAsDataURL(file);
  };

  if (!hasStarted) {
    return <LandingPage onStart={() => setHasStarted(true)} />;
  }

  return (
    <div className="flex h-screen bg-[#0a0510] text-gray-100 font-sans overflow-hidden animate-fade-in">
      {/* Sidebar */}
      <aside className="w-16 md:w-64 bg-[#150a21] border-r border-white/5 flex flex-col items-center md:items-stretch py-6 space-y-3 z-10 shadow-2xl relative">
        <div className="flex items-center justify-center md:justify-start px-0 md:px-6 mb-8 text-purple-400 group cursor-pointer">
           <svg className="w-8 h-8 transition-transform duration-500 ease-bouncy group-hover:rotate-180" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/><path d="M2 17L12 22L22 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/><path d="M2 12L12 17L22 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
           <span className="ml-3 font-bold text-xl tracking-tight hidden md:block text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-fuchsia-400">NeuroFix</span>
        </div>
        
        <NavButton 
          active={activeTab === DebugMode.STATIC_ANALYSIS} 
          onClick={() => setActiveTab(DebugMode.STATIC_ANALYSIS)} 
          icon={<BugIcon />} 
          label="Code Inspector" 
        />
        <NavButton 
          active={activeTab === DebugMode.TRAINING_SIMULATION} 
          onClick={() => setActiveTab(DebugMode.TRAINING_SIMULATION)} 
          icon={<ChartIcon />} 
          label="Training Sim" 
        />
        <NavButton 
          active={activeTab === DebugMode.ARCHITECTURE_DIAGRAM} 
          onClick={() => setActiveTab(DebugMode.ARCHITECTURE_DIAGRAM)} 
          icon={<EyeIcon />} 
          label="Vision Inspector" 
        />
        <NavButton 
          active={activeTab === DebugMode.CHAT} 
          onClick={() => setActiveTab(DebugMode.CHAT)} 
          icon={<ChatIcon />} 
          label="Consultant" 
        />

        <div className="flex-1"></div>

        <div className="px-3 md:px-6 w-full">
            <button 
                onClick={() => setHasStarted(false)}
                className="group w-full flex items-center justify-center md:justify-start px-2 md:px-4 py-3 text-gray-400 hover:text-white hover:bg-white/5 rounded-xl transition-all duration-300 ease-bouncy"
                title="Back to Home"
            >
                <div className="group-hover:-translate-x-1 transition-transform duration-300">
                    <HomeIcon />
                </div>
                <span className="ml-3 font-medium text-sm hidden md:block">Back to Home</span>
            </button>
        </div>
        
        <div className="px-6 py-4 hidden md:block">
          <div className="text-[10px] uppercase tracking-widest text-gray-600 text-center">
            Gemini Powered
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-full relative">
        {/* Header */}
        <header className="h-16 bg-[#150a21]/50 backdrop-blur-md border-b border-white/5 flex items-center justify-between px-6 z-20">
            <h1 className="text-lg font-medium text-gray-200 animate-fade-in">
              {activeTab === DebugMode.STATIC_ANALYSIS && <span className="flex items-center gap-2"><BugIcon/><span className="text-purple-400">/</span> Static Code Analysis</span>}
              {activeTab === DebugMode.TRAINING_SIMULATION && <span className="flex items-center gap-2"><ChartIcon/><span className="text-fuchsia-400">/</span> Training Dynamics Simulator</span>}
              {activeTab === DebugMode.ARCHITECTURE_DIAGRAM && <span className="flex items-center gap-2"><EyeIcon/><span className="text-emerald-400">/</span> Vision Architecture Inspector</span>}
              {activeTab === DebugMode.CHAT && <span className="flex items-center gap-2"><ChatIcon/><span className="text-violet-400">/</span> Expert Chat Consultant</span>}
            </h1>
            
            {activeTab === DebugMode.STATIC_ANALYSIS && (
              <div className="flex items-center space-x-6">
                 <label className="group flex items-center space-x-2 text-sm text-gray-400 cursor-pointer hover:text-gray-200 transition-colors">
                    <div className="relative flex items-center">
                        <input 
                        type="checkbox" 
                        className="peer sr-only"
                        checked={useDeepThink}
                        onChange={(e) => setUseDeepThink(e.target.checked)}
                        />
                        <div className="w-9 h-5 bg-gray-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-purple-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-purple-600 transition-colors duration-300"></div>
                    </div>
                    <span className="font-medium group-hover:text-purple-300 transition-colors">Deep Thinking</span>
                 </label>
                 <button 
                  onClick={handleAnalyze} 
                  disabled={isLoading}
                  className="group relative flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-purple-500 hover:from-purple-500 hover:to-purple-400 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-all duration-300 ease-bouncy disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-purple-500/20 hover:shadow-purple-500/40 hover:-translate-y-0.5 active:translate-y-0 active:scale-95"
                >
                  <div className="absolute inset-0 bg-white/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  {isLoading ? <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"/> : <PlayIcon />}
                  <span className="relative">Run Analysis</span>
                </button>
              </div>
            )}
             {activeTab === DebugMode.TRAINING_SIMULATION && (
                 <button 
                  onClick={handleSimulate} 
                  disabled={isLoading}
                  className="group relative flex items-center space-x-2 bg-gradient-to-r from-fuchsia-600 to-fuchsia-500 hover:from-fuchsia-500 hover:to-fuchsia-400 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-all duration-300 ease-bouncy disabled:opacity-50 shadow-lg shadow-fuchsia-500/20 hover:shadow-fuchsia-500/40 hover:-translate-y-0.5 active:translate-y-0 active:scale-95"
                >
                   <div className="absolute inset-0 bg-white/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  {isLoading ? <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"/> : <SparklesIcon />}
                  <span className="relative">Simulate Run</span>
                </button>
            )}
            {activeTab === DebugMode.ARCHITECTURE_DIAGRAM && uploadedImage && (
                 <button 
                  onClick={handleAnalyzeDiagram} 
                  disabled={isLoading}
                  className="group relative flex items-center space-x-2 bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 text-white px-5 py-2.5 rounded-lg text-sm font-semibold transition-all duration-300 ease-bouncy disabled:opacity-50 shadow-lg shadow-emerald-500/20 hover:shadow-emerald-500/40 hover:-translate-y-0.5 active:translate-y-0 active:scale-95"
                >
                   <div className="absolute inset-0 bg-white/20 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  {isLoading ? <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full"/> : <SparklesIcon />}
                  <span className="relative">Analyze Architecture</span>
                </button>
            )}
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-hidden p-0 relative">
          
          {activeTab === DebugMode.STATIC_ANALYSIS && (
            <div className="flex h-full flex-col md:flex-row">
              <div className="w-full md:w-1/2 h-1/2 md:h-full p-4 border-b md:border-b-0 md:border-r border-white/5 bg-[#0d0714]">
                <CodeEditor code={code} onChange={setCode} label="Input Source Code" />
              </div>
              <div className="w-full md:w-1/2 h-1/2 md:h-full bg-[#11091f]">
                <AnalysisPanel analysisData={analysisResult} simulationData={null} isLoading={isLoading} mode="STATIC_ANALYSIS" />
              </div>
            </div>
          )}

          {activeTab === DebugMode.TRAINING_SIMULATION && (
             <div className="flex h-full flex-col md:flex-row">
                <div className="w-full md:w-1/3 h-auto p-6 bg-[#150a21] border-r border-white/5 flex flex-col gap-4 shadow-xl z-10">
                    <label className="text-xs font-bold text-fuchsia-400 uppercase tracking-widest mb-1 block">Simulation Scenario</label>
                    <div className="relative group">
                        <textarea 
                            className="w-full h-48 bg-[#0a0510] text-gray-200 p-4 rounded-xl border border-gray-700 focus:border-fuchsia-500 focus:ring-2 focus:ring-fuchsia-500/20 outline-none resize-none transition-all duration-300 shadow-inner group-hover:bg-[#0a0510]/80"
                            value={scenario}
                            onChange={(e) => setScenario(e.target.value)}
                            placeholder="Describe the training behavior..."
                        />
                        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity text-xs text-gray-500 pointer-events-none">Editable</div>
                    </div>
                    <div className="text-sm text-gray-500 bg-white/5 p-4 rounded-lg border border-white/5">
                        <p className="mb-2 font-semibold text-gray-400">Quick Prompts:</p>
                        <ul className="space-y-2">
                            {["Overfitting on small dataset", "Gradient explosion", "Learning rate too high"].map((ex, i) => (
                                <li key={i} className="flex items-center group cursor-pointer hover:text-fuchsia-400 transition-colors" onClick={() => setScenario(ex)}>
                                    <span className="w-1.5 h-1.5 rounded-full bg-gray-600 group-hover:bg-fuchsia-500 mr-2 transition-colors"></span>
                                    {ex}
                                </li>
                            ))}
                        </ul>
                    </div>
                </div>
                <div className="flex-1 bg-[#11091f]">
                    <AnalysisPanel analysisData={null} simulationData={simulationResult} isLoading={isLoading} mode="TRAINING_SIMULATION" />
                </div>
             </div>
          )}

          {activeTab === DebugMode.ARCHITECTURE_DIAGRAM && (
             <div className="flex h-full flex-col md:flex-row">
                 <div className="w-full md:w-1/2 h-full p-8 flex flex-col justify-center bg-[#0d0714] border-r border-white/5">
                    {!uploadedImage ? (
                        <div 
                            onDragOver={onDragOver}
                            onDragLeave={onDragLeave}
                            onDrop={onDrop}
                            onClick={() => fileInputRef.current?.click()}
                            className={`flex-1 border-2 border-dashed rounded-3xl flex flex-col items-center justify-center cursor-pointer transition-all duration-300 group ${isDragging ? 'border-emerald-500 bg-emerald-500/10' : 'border-gray-700 hover:border-emerald-500/50 hover:bg-white/5'}`}
                        >
                            <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={onFileSelect} />
                            <div className="p-6 bg-[#150a21] rounded-full mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                                <UploadIcon />
                            </div>
                            <p className="text-xl font-bold text-gray-300 mb-2 group-hover:text-emerald-400 transition-colors">Drop Architecture Diagram</p>
                            <p className="text-sm text-gray-500">or click to browse</p>
                        </div>
                    ) : (
                        <div className="relative w-full h-full rounded-2xl overflow-hidden border border-gray-700 bg-black flex items-center justify-center group">
                            <img src={uploadedImage} alt="Uploaded Diagram" className="max-w-full max-h-full object-contain" />
                            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                <button 
                                    onClick={() => setUploadedImage(null)}
                                    className="bg-red-500/20 text-red-400 border border-red-500/50 px-6 py-2 rounded-lg hover:bg-red-500 hover:text-white transition-all"
                                >
                                    Remove Image
                                </button>
                            </div>
                        </div>
                    )}
                 </div>
                 <div className="w-full md:w-1/2 h-full bg-[#11091f]">
                     {diagramResult ? (
                         <AnalysisPanel analysisData={diagramResult} simulationData={null} isLoading={isLoading} mode="ARCHITECTURE_DIAGRAM" />
                     ) : (
                         <div className="h-full flex flex-col items-center justify-center text-gray-500 p-12 text-center">
                            <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mb-6 animate-pulse">
                                <EyeIcon />
                            </div>
                            <h3 className="text-lg font-medium text-gray-300 mb-2">Awaiting Visual Input</h3>
                            <p className="max-w-xs text-sm">Upload a screenshot of a neural network architecture (paper, whiteboard, or diagram) to generate PyTorch code.</p>
                         </div>
                     )}
                 </div>
             </div>
          )}

          {activeTab === DebugMode.CHAT && (
             <div className="flex flex-col h-full bg-[#11091f]">
                 <div className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth">
                     {chatHistory.map((msg, idx) => (
                         <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                             <div className={`max-w-[80%] rounded-2xl p-4 ${
                                 msg.role === 'user' 
                                 ? 'bg-gradient-to-br from-purple-600 to-fuchsia-600 text-white shadow-lg shadow-purple-500/20 rounded-br-none' 
                                 : 'bg-[#1e1b29] border border-gray-700 text-gray-200 rounded-bl-none'
                             }`}>
                                 <ReactMarkdown 
                                     components={{
                                         code({node, inline, className, children, ...props}: any) {
                                             return !inline ? (
                                                 <div className="bg-[#0d1117] p-2 rounded-md my-2 overflow-x-auto border border-gray-800 text-xs">
                                                     <code className={className} {...props}>{children}</code>
                                                 </div>
                                             ) : (
                                                 <code className="bg-black/30 px-1 py-0.5 rounded text-fuchsia-300 font-mono text-xs" {...props}>{children}</code>
                                             )
                                         }
                                     }}
                                 >
                                     {msg.content}
                                 </ReactMarkdown>
                             </div>
                         </div>
                     ))}
                     {isLoading && chatHistory[chatHistory.length - 1].role === 'user' && (
                          <div className="flex justify-start">
                             <div className="bg-[#1e1b29] border border-gray-700 text-gray-400 rounded-2xl rounded-bl-none p-4 flex items-center space-x-2">
                                 <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce"></div>
                                 <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce delay-75"></div>
                                 <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce delay-150"></div>
                             </div>
                          </div>
                     )}
                 </div>
                 <div className="p-4 bg-[#150a21] border-t border-white/5">
                     <div className="relative">
                         <input 
                             type="text" 
                             className="w-full bg-[#0d0714] border border-gray-700 rounded-xl px-4 py-3 pr-12 text-gray-200 focus:outline-none focus:border-purple-500 focus:ring-1 focus:ring-purple-500/50 transition-all placeholder-gray-600"
                             placeholder="Ask NeuroFix about your model..."
                             value={chatInput}
                             onChange={(e) => setChatInput(e.target.value)}
                             onKeyDown={(e) => e.key === 'Enter' && handleChatSend()}
                             disabled={isLoading}
                         />
                         <button 
                             onClick={handleChatSend}
                             disabled={isLoading || !chatInput.trim()}
                             className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-purple-400 hover:text-white hover:bg-purple-600 rounded-lg transition-all disabled:opacity-50 disabled:hover:bg-transparent"
                         >
                             <svg className="w-5 h-5 transform rotate-90" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
                         </button>
                     </div>
                 </div>
             </div>
          )}
        </div>
      </main>
    </div>
  );
}

const NavButton = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: React.ReactNode, label: string }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center justify-center md:justify-start px-2 md:px-6 py-3 transition-all duration-200 relative group ${active ? 'text-white' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}
  >
    {active && (
      <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-purple-400 to-fuchsia-400 rounded-r shadow-[0_0_10px_rgba(192,132,252,0.5)] animate-pulse"></div>
    )}
    <div className={`transition-transform duration-300 ${active ? 'scale-110 text-purple-400 drop-shadow-[0_0_8px_rgba(168,85,247,0.5)]' : 'group-hover:scale-105 group-hover:text-purple-300'}`}>
        {icon}
    </div>
    <span className={`ml-4 font-medium tracking-wide text-sm hidden md:block transition-all duration-300 ${active ? 'text-transparent bg-clip-text bg-gradient-to-r from-purple-200 to-white font-bold' : ''}`}>
        {label}
    </span>
    {active && <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-transparent pointer-events-none"></div>}
  </button>
);