import { GoogleGenAI, Type } from "@google/genai";
import { ANALYSIS_SCHEMA, SIMULATION_SCHEMA, AnalysisResult, SimulationResult, ChatMessage } from "../types";

// Initialize Gemini Client
// CRITICAL: Ensure process.env.API_KEY is available.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeCode = async (code: string, deepThink: boolean = false): Promise<AnalysisResult> => {
  const modelName = deepThink ? 'gemini-3-pro-preview' : 'gemini-2.5-flash';
  
  const prompt = `
    You are an expert Machine Learning Engineer and Code Auditor.
    Analyze the following ML code (Python/PyTorch/TensorFlow/JAX).
    Identify:
    1. Logical bugs (dimension mismatches, gradient exploding risks, data leakage).
    2. Performance bottlenecks (data loading, unnecessary tensor copies).
    3. Best practice violations.
    
    Return a structured JSON response with a summary, list of issues, and a corrected version of the key problematic sections (or the whole file if short).
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelName,
      contents: [
        { role: 'user', parts: [{ text: prompt }, { text: `\n\nCODE TO ANALYZE:\n${code}` }] }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: ANALYSIS_SCHEMA,
        // Use thinking if deep analysis is requested and supported by the model (Pro only mostly)
        thinkingConfig: deepThink ? { thinkingBudget: 4096 } : undefined, 
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    return JSON.parse(text) as AnalysisResult;
  } catch (error) {
    console.error("Analysis failed:", error);
    throw error;
  }
};

export const simulateTraining = async (scenario: string): Promise<SimulationResult> => {
  const prompt = `
    You are a simulator for Machine Learning Training dynamics.
    The user will describe a training scenario (e.g., "Overfitting on a small dataset", "Learning rate too high", "Good convergence").
    
    1. Generate a realistic JSON dataset of training metrics (loss, val_loss, accuracy, val_accuracy) for 20 epochs that visually represents this scenario.
    2. Provide a diagnosis of why the curves look this way.
    3. Provide a description of the simulated outcome.

    User Scenario: "${scenario}"
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: SIMULATION_SCHEMA,
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    return JSON.parse(text) as SimulationResult;
  } catch (error) {
    console.error("Simulation failed:", error);
    throw error;
  }
};

export const sendChatMessage = async (history: ChatMessage[], newMessage: string): Promise<string> => {
  try {
    const chat = ai.chats.create({
      model: 'gemini-3-pro-preview',
      config: {
        systemInstruction: "You are NeuroFix, an advanced AI assistant specialized in debugging Machine Learning models. Be concise, technical, and helpful. Use markdown for code.",
      },
      history: history.map(h => ({
        role: h.role,
        parts: [{ text: h.content }]
      }))
    });

    const result = await chat.sendMessage({ message: newMessage });
    return result.text || "I couldn't generate a response.";
  } catch (error) {
    console.error("Chat failed:", error);
    return "Error communicating with the AI. Please try again.";
  }
};

export const analyzeDiagram = async (imageBase64: string, mimeType: string): Promise<AnalysisResult> => {
  const prompt = `
    You are an expert ML Architect. Analyze this neural network architecture diagram.
    
    1. Describe the architecture in the diagram (e.g., ResNet-style blocks, U-Net skip connections, Transformer attention heads).
    2. Identify potential flaws or bottlenecks visible in the design (e.g., severe information bottlenecks, missing residual connections in deep networks, mismatched tensor shapes implied).
    3. Generate the corresponding PyTorch code implementation for this architecture.
    
    Return a structured JSON response.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            {
              inlineData: {
                mimeType: mimeType,
                data: imageBase64
              }
            },
            { text: prompt }
          ]
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: ANALYSIS_SCHEMA,
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    return JSON.parse(text) as AnalysisResult;
  } catch (error) {
    console.error("Diagram analysis failed:", error);
    throw error;
  }
};