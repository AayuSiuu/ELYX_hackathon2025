import React, { useRef, useState } from 'react';
import { BugIcon, ChartIcon, ChatIcon } from './Icons';

interface LandingPageProps {
  onStart: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onStart }) => {
  return (
    <div className="min-h-screen bg-[#0a0510] text-gray-100 flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-20 -left-20 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-fuchsia-500/10 rounded-full blur-3xl animate-float-delayed"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-purple-500/5 via-transparent to-transparent opacity-50"></div>
      </div>

      <div className="z-10 max-w-5xl w-full flex flex-col items-center text-center space-y-12">
        
        {/* Hero Section */}
        <div className="flex flex-col items-center space-y-6 animate-fade-in-up">
          <div className="group relative inline-flex items-center space-x-2 bg-white/5 border border-white/10 rounded-full px-4 py-1.5 mb-4 hover:border-purple-500/50 hover:bg-white/10 transition-all duration-500 ease-bouncy cursor-default">
             <div className="relative">
                <span className="absolute inline-flex h-full w-full rounded-full bg-fuchsia-400 opacity-75 animate-ping"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-fuchsia-500"></span>
             </div>
             <span className="text-xs font-mono text-gray-400 uppercase tracking-widest group-hover:text-purple-400 transition-colors">System Online v1.0</span>
          </div>
          
          <div className="title-container inline-block cursor-default">
            <h1 className="text-5xl md:text-8xl font-bold tracking-tight relative">
              <span className="text-white relative z-10 text-glow glitch-target" data-text="Neuro">Neuro</span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-fuchsia-400 relative z-10 animate-pulse-slow glitch-target" data-text="Fix">Fix</span>
              {/* Decorative background blur for text */}
              <div className="absolute inset-0 blur-3xl bg-purple-500/20 -z-10 rounded-full opacity-50 transform scale-110"></div>
            </h1>
          </div>
          
          <p className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto leading-relaxed">
            Your intelligent companion for debugging machine learning models. 
            Analyze architectures, simulate training dynamics, and consult with AI experts in real-time.
          </p>
        </div>

        {/* Feature Grid with Group Hover Effect */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full px-4 md:px-0 perspective-1000 group">
          <FeatureCard 
            icon={<BugIcon />} 
            title="Static Analysis" 
            desc="Instant code auditing to detect dimension mismatches and logical flaws."
            delay="0ms"
            color="purple"
          />
          <FeatureCard 
            icon={<ChartIcon />} 
            title="Training Simulation" 
            desc="Visualize loss landscapes and diagnose convergence issues before training."
            delay="100ms"
            color="fuchsia"
          />
          <FeatureCard 
            icon={<ChatIcon />} 
            title="Expert Consultant" 
            desc="Interactive chat with a specialized AI agent for architectural advice."
            delay="200ms"
            color="violet"
          />
        </div>

        {/* CTA */}
        <button 
          onClick={onStart}
          className="group relative inline-flex items-center justify-center px-8 py-4 text-lg font-bold text-white transition-all duration-300 ease-bouncy bg-gradient-to-r from-purple-600 to-purple-500 rounded-xl hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/40 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-600 focus:ring-offset-[#0f172a] mt-8 cursor-pointer overflow-hidden"
        >
          <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out skew-y-12"></div>
          <span className="relative flex items-center">
            Initialize Debugger
            <svg className="w-5 h-5 ml-2 transition-transform duration-300 ease-bouncy group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </span>
        </button>

        <p className="text-sm text-gray-500 mt-8 font-mono opacity-60 hover:opacity-100 transition-opacity">
          Powered by Google Gemini 2.5 Flash & 3 Pro
        </p>
      </div>
    </div>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  desc: string;
  delay: string;
  color: 'purple' | 'fuchsia' | 'violet';
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, desc, delay, color }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  const [glarePosition, setGlarePosition] = useState({ x: 50, y: 50 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    // Increased tilt range for more "pop"
    const maxTilt = 15;

    const rotateY = ((x - centerX) / centerX) * maxTilt; 
    const rotateX = ((centerY - y) / centerY) * maxTilt; 

    setRotation({ x: rotateX, y: rotateY });
    
    // Glare moves opposite to mouse to simulate reflection
    const glareX = 100 - ((x / rect.width) * 100);
    const glareY = 100 - ((y / rect.height) * 100);
    
    setGlarePosition({ x: glareX, y: glareY });
  };

  const handleMouseEnter = () => setIsHovered(true);
  
  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotation({ x: 0, y: 0 });
  };

  const colorClasses = {
    purple: 'border-purple-500/30 text-purple-100',
    fuchsia: 'border-fuchsia-500/30 text-fuchsia-100',
    violet: 'border-violet-500/30 text-violet-100',
  };

  const glowClasses = {
    purple: 'group-hover/card:border-purple-400/80',
    fuchsia: 'group-hover/card:border-fuchsia-400/80',
    violet: 'group-hover/card:border-violet-400/80',
  };

  const bgGradient = {
    purple: 'bg-gradient-to-br from-[#150a21]/90 to-purple-900/20',
    fuchsia: 'bg-gradient-to-br from-[#150a21]/90 to-fuchsia-900/20',
    violet: 'bg-gradient-to-br from-[#150a21]/90 to-violet-900/20',
  };

  return (
    <div 
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      className={`
        relative p-8 rounded-3xl text-left border backdrop-blur-xl group/card
        transform-gpu
        
        /* Base Styling */
        ${colorClasses[color]} ${bgGradient[color]}

        /* Group Hover Effects (Siblings fade out) */
        group-hover:scale-95 group-hover:opacity-40 group-hover:grayscale-[0.5]

        /* Active Hover Effects (Self overrides siblings) */
        hover:!scale-100 hover:!opacity-100 hover:!grayscale-0 hover:z-50
        
        /* Transition */
        transition-all duration-300
        ${glowClasses[color]}
      `}
      style={{
        transformStyle: 'preserve-3d',
        transform: isHovered 
          ? `perspective(800px) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg) scale3d(1.02, 1.02, 1.02)` 
          : 'perspective(800px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)', 
        transition: isHovered ? 'transform 0.1s ease-out, box-shadow 0.1s ease-out' : 'all 0.5s ease-in-out',
        animationDelay: delay,
        boxShadow: isHovered 
            ? `${-rotation.y * 1.5}px ${rotation.x * 1.5}px 30px rgba(0,0,0,0.5), 0 0 25px ${color === 'purple' ? 'rgba(168,85,247,0.3)' : color === 'fuchsia' ? 'rgba(217,70,239,0.3)' : 'rgba(139,92,246,0.3)'}`
            : '0 0 15px rgba(0,0,0,0.2)'
      }}
    >
      {/* Holographic Glare */}
      <div 
        className="absolute inset-0 pointer-events-none z-20 mix-blend-overlay transition-opacity duration-300 opacity-0 group-hover/card:opacity-100 rounded-3xl"
        style={{
          transform: 'translateZ(1px)', 
          background: `
            radial-gradient(
              circle at ${glarePosition.x}% ${glarePosition.y}%, 
              rgba(255,255,255,0.4) 0%, 
              rgba(255,255,255,0.1) 40%, 
              transparent 70%
            )
          `
        }}
      />

      {/* Content Container - Parallax Layer */}
      <div 
        className="relative z-10 pointer-events-none"
        style={{ transform: 'translateZ(25px)' }}
      >
          <div className={`w-14 h-14 bg-white/5 rounded-2xl flex items-center justify-center mb-6 text-gray-300 border border-white/5 transition-all duration-500 ease-bouncy group-hover/card:scale-110 group-hover/card:rotate-3 shadow-lg ${color === 'purple' ? 'group-hover/card:text-purple-400 group-hover/card:bg-purple-500/20' : color === 'fuchsia' ? 'group-hover/card:text-fuchsia-400 group-hover/card:bg-fuchsia-500/20' : 'group-hover/card:text-violet-400 group-hover/card:bg-violet-500/20'}`}>
            {icon}
          </div>
          <h3 className="text-2xl font-bold text-white mb-3 tracking-tight drop-shadow-md">{title}</h3>
          <p className="text-base text-gray-300 leading-relaxed drop-shadow-md">{desc}</p>
      </div>
    </div>
  );
};