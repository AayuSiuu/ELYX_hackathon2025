import React from 'react';

interface CodeEditorProps {
  code: string;
  onChange: (value: string) => void;
  readOnly?: boolean;
  label?: string;
}

export const CodeEditor: React.FC<CodeEditorProps> = ({ code, onChange, readOnly = false, label }) => {
  return (
    <div className="flex flex-col h-full bg-[#0d1117] rounded-lg border border-gray-700 overflow-hidden">
      {label && (
        <div className="px-4 py-2 bg-gray-800 border-b border-gray-700 text-xs font-mono text-gray-400 uppercase tracking-wider flex justify-between items-center">
            <span>{label}</span>
            <span className="text-[10px] text-gray-500">Python / PyTorch</span>
        </div>
      )}
      <textarea
        className="flex-1 w-full h-full p-4 bg-[#0d1117] text-gray-300 font-mono text-sm resize-none focus:outline-none focus:ring-1 focus:ring-purple-500/50 leading-relaxed"
        value={code}
        onChange={(e) => onChange(e.target.value)}
        spellCheck={false}
        readOnly={readOnly}
        placeholder={readOnly ? "Output will appear here..." : "# Paste your ML model code here for analysis...\nimport torch\nimport torch.nn as nn..."}
      />
    </div>
  );
};