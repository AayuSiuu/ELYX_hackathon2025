import React from 'react';
import { AnalysisResult, SimulationResult, Issue } from '../types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import ReactMarkdown from 'react-markdown';
import { CodeEditor } from './CodeEditor';

interface AnalysisPanelProps {
  analysisData: AnalysisResult | null;
  simulationData: SimulationResult | null;
  isLoading: boolean;
  mode: 'STATIC_ANALYSIS' | 'TRAINING_SIMULATION' | 'ARCHITECTURE_DIAGRAM';
}

export const AnalysisPanel: React.FC<AnalysisPanelProps> = ({ analysisData, simulationData, isLoading, mode }) => {
  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full text-purple-400 flex-col gap-6">
        <div className="relative">
             <div className="w-16 h-16 border-4 border-purple-500/30 border-t-purple-500 rounded-full animate-spin"></div>
             <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-8 h-8 bg-purple-500 rounded-full animate-pulse"></div>
             </div>
        </div>
        <p className="text-sm font-mono tracking-widest animate-pulse text-purple-300">NEURAL PROCESSING...</p>
      </div>
    );
  }

  if (mode === 'TRAINING_SIMULATION' && simulationData) {
    return (
      <div className="h-full overflow-y-auto p-6 space-y-6">
        <div className="bg-[#1e1b29]/50 backdrop-blur border border-gray-700 p-6 rounded-2xl shadow-xl transform transition-all hover:border-gray-600">
          <h3 className="text-lg font-bold text-white mb-2 flex items-center">
            <span className="w-2 h-2 bg-emerald-400 rounded-full mr-2 animate-pulse"></span>
            Simulation Diagnosis
          </h3>
          <p className="text-gray-300 leading-relaxed text-lg">{simulationData.diagnosis}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-[#1e1b29] p-4 rounded-2xl border border-gray-700 h-80 shadow-lg hover:shadow-2xl transition-shadow duration-300">
            <h4 className="text-xs font-mono text-gray-400 mb-4 uppercase tracking-wider">Loss Convergence</h4>
            <ResponsiveContainer width="100%" height="100%">
                <LineChart data={simulationData.metrics}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.5} />
                <XAxis dataKey="epoch" stroke="#9ca3af" tick={{fontSize: 12}} />
                <YAxis stroke="#9ca3af" tick={{fontSize: 12}} />
                <Tooltip 
                    contentStyle={{ backgroundColor: 'rgba(21, 10, 33, 0.9)', border: '1px solid #374151', borderRadius: '8px', color: '#f3f4f6', backdropFilter: 'blur(4px)' }}
                    itemStyle={{ fontSize: '12px' }}
                />
                <Legend wrapperStyle={{paddingTop: '10px'}} />
                <Line type="monotone" dataKey="loss" stroke="#ef4444" strokeWidth={3} dot={{r: 0}} activeDot={{r: 6, strokeWidth: 0}} name="Train Loss" animationDuration={1500} />
                <Line type="monotone" dataKey="val_loss" stroke="#f87171" strokeDasharray="5 5" strokeWidth={2} dot={{r: 0}} activeDot={{r: 4}} name="Val Loss" animationDuration={1500} />
                </LineChart>
            </ResponsiveContainer>
            </div>

            <div className="bg-[#1e1b29] p-4 rounded-2xl border border-gray-700 h-80 shadow-lg hover:shadow-2xl transition-shadow duration-300">
            <h4 className="text-xs font-mono text-gray-400 mb-4 uppercase tracking-wider">Accuracy Metrics</h4>
            <ResponsiveContainer width="100%" height="100%">
                <LineChart data={simulationData.metrics}>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.5} />
                <XAxis dataKey="epoch" stroke="#9ca3af" tick={{fontSize: 12}} />
                <YAxis domain={[0, 1]} stroke="#9ca3af" tick={{fontSize: 12}} />
                <Tooltip contentStyle={{ backgroundColor: 'rgba(21, 10, 33, 0.9)', border: '1px solid #374151', borderRadius: '8px', color: '#f3f4f6', backdropFilter: 'blur(4px)' }} />
                <Legend wrapperStyle={{paddingTop: '10px'}} />
                <Line type="monotone" dataKey="accuracy" stroke="#8b5cf6" strokeWidth={3} dot={{r: 0}} activeDot={{r: 6, strokeWidth: 0}} name="Train Acc" animationDuration={1500} />
                <Line type="monotone" dataKey="val_accuracy" stroke="#a78bfa" strokeDasharray="5 5" strokeWidth={2} dot={{r: 0}} activeDot={{r: 4}} name="Val Acc" animationDuration={1500} />
                </LineChart>
            </ResponsiveContainer>
            </div>
        </div>
      </div>
    );
  }

  // Handle both code analysis and architecture diagram analysis with the same view
  if ((mode === 'STATIC_ANALYSIS' || mode === 'ARCHITECTURE_DIAGRAM') && analysisData) {
    return (
      <div className="h-full flex flex-col overflow-hidden">
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
            <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-6 rounded-2xl border border-gray-700 shadow-xl">
                <h3 className="text-lg font-bold text-white mb-2">Executive Summary</h3>
                <p className="text-gray-300 leading-relaxed">{analysisData.summary}</p>
            </div>

            <div className="space-y-4">
                <h3 className="text-xs font-bold font-mono text-gray-500 uppercase tracking-widest pl-1">Detected Issues ({analysisData.issues.length})</h3>
                {analysisData.issues.map((issue, idx) => (
                    <IssueCard key={idx} issue={issue} index={idx} />
                ))}
            </div>

            {analysisData.fixedCode && (
                 <div className="mt-8 h-96 rounded-2xl overflow-hidden border border-gray-700 shadow-2xl">
                    <CodeEditor 
                        code={analysisData.fixedCode} 
                        onChange={() => {}} 
                        readOnly={true} 
                        label={mode === 'ARCHITECTURE_DIAGRAM' ? "Generated Implementation" : "Suggested Fix"}
                    />
                 </div>
            )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center h-full text-gray-500 space-y-6">
      <div className="relative group cursor-pointer">
        <div className="absolute -inset-4 bg-purple-500/20 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
        <svg className="relative w-24 h-24 opacity-20 group-hover:opacity-50 transition-all duration-500 ease-bouncy group-hover:scale-110 group-hover:rotate-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
        </svg>
      </div>
      <p className="text-lg font-medium tracking-wide">Ready for analysis</p>
    </div>
  );
};

const IssueCard: React.FC<{ issue: Issue, index: number }> = ({ issue, index }) => {
    const severityStyles = {
        CRITICAL: {
            border: 'group-hover:border-red-500/50',
            bg: 'bg-red-900/10',
            text: 'text-red-200',
            badge: 'bg-red-500',
            shadow: 'hover:shadow-red-500/10'
        },
        WARNING: {
            border: 'group-hover:border-yellow-500/50',
            bg: 'bg-yellow-900/10',
            text: 'text-yellow-200',
            badge: 'bg-yellow-500',
            shadow: 'hover:shadow-yellow-500/10'
        },
        INFO: {
            border: 'group-hover:border-violet-500/50',
            bg: 'bg-violet-900/10',
            text: 'text-violet-200',
            badge: 'bg-violet-500',
            shadow: 'hover:shadow-violet-500/10'
        }
    };

    const style = severityStyles[issue.severity];

    return (
        <div 
            className={`group relative p-5 rounded-xl border border-gray-700/50 ${style.bg} ${style.text} transition-all duration-300 ease-bouncy hover:-translate-y-1 hover:bg-opacity-20 ${style.border} shadow-lg hover:shadow-2xl ${style.shadow}`}
            style={{ animationDelay: `${index * 100}ms` }}
        >
            <div className="flex justify-between items-center mb-3">
                <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${style.badge} text-white shadow-sm`}>
                    {issue.severity}
                </span>
                {issue.line && <span className="text-xs font-mono opacity-60">Line {issue.line}</span>}
            </div>
            <p className="font-medium text-sm mb-3 leading-relaxed">{issue.description}</p>
            <div className="relative overflow-hidden rounded-lg bg-black/20 p-3 border border-white/5">
                <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-transparent via-gray-500 to-transparent opacity-50"></div>
                <div className="text-xs font-mono opacity-90 pl-2">
                    <span className="text-gray-500 select-none mr-2">FIX:</span> 
                    {issue.suggestion}
                </div>
            </div>
        </div>
    );
};